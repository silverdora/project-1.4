﻿using System;
namespace Chapeau.Models
{
	public enum Status
	{
		//All,
		Ordered,
		InProgress,
		ReadyToBeServed,
		Served,
        Paid //  in order to finalise the order,  

    }
}



using System;
namespace Chapeau.Models
{
	public enum Role
	{
		Server,
		Bar,
		Kitchen,
		Manager
	}
}

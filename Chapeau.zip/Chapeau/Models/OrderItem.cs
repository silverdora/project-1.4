﻿namespace Chapeau.Models
{
    public class OrderItem
    {
        public int OrderID { get; set; }
        public MenuItem MenuItem { get; set; }
        public int ItemID { get; set; } //is used to change status
        public DateTime IncludeDate { get; set; }
        public TimeSpan WaitingTime
        {
            get
            {
                return DateTime.Now - IncludeDate;
            }
        }
        public Status Status { get; set; }
        public int Quantity { get; set; }
        public string? Comment { get; set; }
        public OrderItem()
        {

        }
        

        public OrderItem(int itemID, MenuItem menuItem, DateTime includeDate, Status status, int quantity, string? comment)
        {
            ItemID = itemID;
            MenuItem = menuItem;
            IncludeDate = includeDate;
            Status = status;
            Quantity = quantity;
            Comment = comment;
        }
    }
}


namespace Chapeau.Models
{
    public enum PaymentType
    {
        Cash,
        DebitCard,
        CreditCard
    }
} 
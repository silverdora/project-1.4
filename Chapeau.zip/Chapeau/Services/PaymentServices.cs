﻿using Chapeau.Models;
using Chapeau.Repositories.Interfaces;
using Chapeau.Repository.Interface;
using Chapeau.Services.Interfaces;
using Chapeau.ViewModels;
using Microsoft.Data.SqlClient; 


namespace Chapeau.Services
{
    public class PaymentService : IPaymentService
    {
        private readonly IPaymentRepository _paymentRepository;
        private readonly string _connectionString;

        //Mo added in order to free the table after payment is done Sprint3
        private readonly ITableRepository _tableRepository;
        //public PaymentService(ITableRepository tableRepository)
        //{
        //    _tableRepository = tableRepository;
        //}

        public void MarkOrderAsPaid(int orderID)
        {
            _tableRepository.MarkOrderAsPaid(orderID);
        }
        public int? GetLatestUnpaidOrderIdByTable(int tableId)
        {
            return _tableRepository.GetLatestUnpaidOrderIdByTable(tableId);
        }

        /////////////////////////////////////////////////////////
        public PaymentService(IPaymentRepository paymentRepository, ITableRepository tableRepository)
        {
            _paymentRepository = paymentRepository;
            _tableRepository = tableRepository;
        }

        public List<Payment> GetAllPayments(int orderID)
        {
            return _paymentRepository.GetAllPayments();
        }

        public void AddPayment(Payment payment)
        {
            _paymentRepository.AddPayment(payment);
        }
        public void CompletePayment(int id)
        {
            _paymentRepository.MarkPaymentComplete(id);
        }

        // Save or update the full payment details
        public void CompletePayment(Payment payment)
        {
            if (payment == null) return;
            // Either add new payment or update existing one, depending on your logic
            _paymentRepository.AddPayment(payment);
            // or _paymentRepository.UpdatePayment(payment); if you have update logic
        }

        public void SavePayment(FinishOrderViewModel model)
        {
            var payment = new Payment
            {
                orderID = model.OrderID,
                paymentType = model.PaymentType,
                amountPaid = model.AmountPaid,
                tipAmount = model.TipAmount,
                paymentDAte = DateTime.Now,
                lowVatAmount = model.LowVatAmount,
                highVATAmount = model.HighVatAmount,
                Feedback = model.Feedback
            };

            _paymentRepository.AddPayment(payment);
        }
        public void SaveIndividualPayment(int orderId, decimal amountPaid, decimal tipAmount, string paymentType, string feedback)
        {
            var payment = new Payment
            {
                orderID = orderId,
                amountPaid = amountPaid,
                tipAmount = tipAmount,
                paymentType = (PaymentType)Enum.Parse(typeof(PaymentType), paymentType, true),
                Feedback = feedback,
                paymentDAte = DateTime.Now
            };

            _paymentRepository.Add(payment);
        }


        //Mo added in order to free the table after payment is done Sprint3




    }
}
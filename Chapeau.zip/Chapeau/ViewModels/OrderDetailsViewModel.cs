﻿//using Chapeau.Models;

//namespace Chapeau.ViewModels
//{
//    public class MenuSelectionViewModel
//    {
//        public int TableID { get; set; }
//        public int OrderID { get; set; } // ✅ NEW
//        //public MenuCard? SelectedCard { get; set; }
//        //public MenuCategory? SelectedCategory { get; set; }
//        public string? SelectedCard { get; set; }
//        public string? SelectedCategory { get; set; }
//        public List<MenuItem> Items { get; set; } = new List<MenuItem>();

//        //// Holds user selection, using int= itemID and  int quantity
//        //public Dictionary<int, int> Quantities { get; set; } = new();

//        public string Notes { get; set; } = string.Empty;

//        //to be able to show the buttons that are not current 
        

       


//    }
//}
